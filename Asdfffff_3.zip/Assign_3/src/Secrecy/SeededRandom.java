package Secrecy;

import java.util.Random;

public class SeededRandom
{
    /**
     * This code perform a simple encryption of plaintext by using random number generator.
     * Program go to stringBuilder and returns it after execute the method.
     * @param plaintext
     * @param shift
     * @return
     */
    public static String encryption (String plaintext, int shift)
    {

        if (shift == 0)
        {
            return plaintext;
        }

        StringBuilder RNG = new StringBuilder();
        Random mixer = new Random();
        for (int i = 0; i < plaintext.length(); i++)
        {
            char c = plaintext.charAt(i);
            int mixerOutput;
            mixerOutput = mixer.nextInt() & 0x7f;
            int encryptedChar = c ^ mixerOutput;
            RNG.append(encryptedChar);
        }
        return RNG.toString();
    }
}