package Secrecy;
import java.io.IOException;

public interface TransmogrifierInterface
{
    void mutate(String text, int shift) throws IOException;

    void getKey();
    void Antikey();

    void TransmogrifierPolysubstitution();

    interface TransmogrifierOffset
    {
        String mutate(String text, int shift);
    }

    interface TransmogrifierPolySubstitution
    {
        String Cipher (String plaintext, String keyword);
    }

    interface TransmogrifierChained
    {
        String encryption (String plaintext, int shift);
    }
}


