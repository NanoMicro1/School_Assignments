package Secrecy;

public class StaticOffset
{
    /**
     * This method can take a plaintext string and an integer shift value as input. And return a encrypted text accdording to input value.
     * @param plaintext
     * @param shift
     * @return
     */
    public static String Mutate(String plaintext, int shift)
    {

        if (shift == 0)
        {
            return plaintext;
        }

        StringBuilder Offsetbased = new StringBuilder();
        
        for (int i = 0; i < plaintext.length(); i++)
        {
            char c = plaintext.charAt(i);
            if (Character.isLetter(c))
            {
                int code = (int) c;
                int shiftedCode = code + shift;
                if ((Character.isUpperCase(c) && shiftedCode > 'Z') || (Character.isLowerCase(c) && shiftedCode > 'z'))
                {
                    shiftedCode -= 26;
                }
                Offsetbased.append((char) shiftedCode);
            } else
                {
                    Offsetbased.append(c);
                }
        }
        return Offsetbased.toString();
    }
}

