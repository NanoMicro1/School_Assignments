package Secrecy;

public class StringBased
{

    /**
     * This method implements a string-based cipher that can encrypts a plaintext by using keyword.(you can change Keyword in Transmogrifier class)
     * This method called shiftChar is then called to shift the plaintext characters by shift value.
     * @param plaintext
     * @param keyword
     * @return
     */
    public static String Cipher(String plaintext, String keyword)
    {

        StringBuilder StringBased = new StringBuilder();

        int key = 0;

        for (int i = 0; i < plaintext.length(); i++)
        {
            char plainChar = plaintext.charAt(i);
            char keywordChar = keyword.charAt(key % keyword.length());
            int shift = Character.toUpperCase(keywordChar) - 'A';

            if (!Character.isLetter(plainChar))
            {
                StringBased.append(plainChar);
                continue;
            }

            char cipheredChar = shiftChar(plainChar, shift);
            StringBased.append(cipheredChar);

            key++;
        }

        return StringBased.toString();
    }

    private static char shiftChar(char c, int shift)
    {
        char basic = Character.isUpperCase(c) ? 'A' : 'a';
        int code = c - basic;
        int shiftedCode = (code + shift) % 26;
        return (char) (basic + shiftedCode);
    }
}