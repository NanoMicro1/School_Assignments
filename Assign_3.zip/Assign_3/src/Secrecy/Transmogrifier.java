package Secrecy;
import java.io.*;


public class Transmogrifier
{
    public static void main(String[] args) throws IOException
    {

        /**
         * //In this block of code, you can bring the textfile. Use mutate method in StaticOffset class to encrypt the text in a textfile.
         */
        StringBuilder Offset = new StringBuilder();
        int key1 = 0;
        String fileName = "C:/Work/IntelliJ_project/Assign_3/ASSIGN_3.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName)))
        {
            String line;
            while ((line = reader.readLine()) != null)
            {
                Offset.append(StaticOffset.Mutate(line, key1)).append("\n");
            }
            System.out.println(Offset + "\n\n");
        }


        /**
         * In this block of code, you can bring the textfile. Use cipher method in StringBased class to encrypt the text in a textfile.
         */
        StringBuilder Stringbasedcipher = new StringBuilder();
        String Keyword = "apple";
        String fileName2 = "C:/Work/IntelliJ_project/Assign_3/ASSIGN_3.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName2)))
        {
            String line2;
            while((line2 = reader.readLine()) !=null)
            {
                Stringbasedcipher.append(StringBased.Cipher(line2, (Keyword))).append("\n");
            }
            System.out.println(Stringbasedcipher + "\n\n");
        }


        /**
         * In this block of code, you can bring the textfile. Use encryption method in SeededRandom class to encrypt the text in a textfile.
         */
        StringBuilder RNG = new StringBuilder();
        int key3 = 1;
        String fileName3 = "C:/Work/IntelliJ_project/Assign_3/ASSIGN_3.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName3)))
        {
            String line3;
            while ((line3 = reader.readLine()) !=null)
            {
                RNG.append(SeededRandom.encryption(line3, key3)).append("\n");
            }
            System.out.println(RNG);
        }


        /**
         * Code below can make and save the output in console to a textfile individually.
         */
        try
        {
            PrintStream console = System.out;

            OutputStream fileOut1 = new FileOutputStream("Encryption Result 1.txt");
            PrintStream filePrintStream = new PrintStream(fileOut1);
            System.setOut(filePrintStream);
            System.out.println(Offset);
            filePrintStream.flush();
            filePrintStream.close();


            OutputStream fileOut2 = new FileOutputStream("Encryption Result 2.txt");
            PrintStream filePrintStream2 = new PrintStream(fileOut2);
            System.setOut(filePrintStream2);
            System.out.println(Stringbasedcipher);
            filePrintStream.flush();
            filePrintStream.close();


            OutputStream fileOut3 = new FileOutputStream("Encryption Result 3.txt");
            PrintStream filePrintStream3 = new PrintStream(fileOut3);
            System.setOut(filePrintStream3);
            System.out.println(RNG);
            filePrintStream.flush();
            filePrintStream.close();

            System.setOut(console);
        } catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
    }
}